from django.db import models

class Job(models.Model):
    fullname = models.CharField(max_length=255)
    tel = models.CharField(max_length=255)
    position = models.CharField(max_length=255)

    def __str__(self):
        return self.fullname
    
class Position(models.Model):
    title = models.CharField(max_length=255)
    salary = models.IntegerField(default=10000)
    manager = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.title