from django.shortcuts import render
from django.http import HttpResponse
from .models import Job

def Home(request):
    if request.method == 'POST':
        data = request.POST.copy()
        print('DATA: ',data)
        fullname = data.get('fullname')
        tel = data.get('tel')
        position = data.get('position')
        print('Fullname: ',fullname)
        print('Tel: ',tel)
        print('Position: ',position)

        newjob = Job()
        newjob.fullname = fullname
        newjob.tel = tel
        newjob.position = position
        newjob.save()

    return render(request, 'myapp/home.html')

