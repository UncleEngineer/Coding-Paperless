from django.contrib import admin
from .models import Job, Position

admin.site.register(Job)
admin.site.register(Position)

